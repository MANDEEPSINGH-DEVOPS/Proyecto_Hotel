package com.example.APP_HOTEL.model;

public class Habitacion {
}
