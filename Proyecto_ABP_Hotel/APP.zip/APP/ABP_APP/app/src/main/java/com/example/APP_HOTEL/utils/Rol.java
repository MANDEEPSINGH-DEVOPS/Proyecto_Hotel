package com.example.APP_HOTEL.utils;

public enum Rol {
    admin,
    recepcionista,
    cliente;
}
