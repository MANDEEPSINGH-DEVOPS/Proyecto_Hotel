package com.example.APP_HOTEL.model;

import com.example.APP_HOTEL.utils.Estado;
import com.example.APP_HOTEL.utils.Rol;

import java.util.Date;

public class User {
    private int id;
    private String username;
    private String email;
    private String password;
    private Rol rol;
    private Estado estado;
    private String fecha_registro;



}
