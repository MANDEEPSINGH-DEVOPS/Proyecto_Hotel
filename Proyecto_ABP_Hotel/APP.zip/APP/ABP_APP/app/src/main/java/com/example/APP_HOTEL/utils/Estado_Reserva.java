package com.example.APP_HOTEL.utils;

public enum Estado_Reserva {
    reservado,
    cancelado,
    completado;
}

