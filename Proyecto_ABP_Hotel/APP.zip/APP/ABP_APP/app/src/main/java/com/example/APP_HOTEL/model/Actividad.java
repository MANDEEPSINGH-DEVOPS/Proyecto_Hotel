package com.example.APP_HOTEL.model;

import java.time.LocalDate;
import java.util.Date;

public class Actividad {

    private int id;
    private String nom;
    private String descripcion;
    private float precio;
    private int cupo;
    private String fecha_actividad;
    private String urlImage;

    public Actividad(int id, String nom, String descripcion, float precio, int cupo, String fecha_actividad, String urlImage) {
        this.id = id;
        this.nom = nom;
        this.descripcion = descripcion;
        this.precio = precio;
        this.cupo = cupo;
        this.fecha_actividad = fecha_actividad;
        this.urlImage = urlImage;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getCupo() {
        return cupo;
    }

    public void setCupo(int cupo) {
        this.cupo = cupo;
    }

    public String getFecha_actividad() {
        return fecha_actividad;
    }

    public void setFecha_actividad(String fecha_actividad) {
        this.fecha_actividad = fecha_actividad;
    }

    public String getUrlImage() {
        return urlImage;
    }

    public void setUrlImage(String urlImage) {
        this.urlImage = urlImage;
    }
}
