package com.example.APP_HOTEL.utils;

public enum Estado {
    activo,
    eliminado
}
